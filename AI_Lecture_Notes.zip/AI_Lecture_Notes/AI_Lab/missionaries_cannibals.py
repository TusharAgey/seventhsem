def production_rules(left_bank, right_bank):
	
